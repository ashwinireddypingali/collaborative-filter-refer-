# RecommenderSystems_PyData_2016
Slides:
https://goo.gl/ehBnhf
